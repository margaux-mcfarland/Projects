%Task2
%efficient way to generate matrix
%Margaux McFarland, CSC1 1320-112, ID: 107731341, Assignment 4

M = [17:1:20; 12:-3:3]


