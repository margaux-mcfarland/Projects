%Task1.m
%uses colon operator and linspace function to create vectors
%Margaux McFarland, CSC1 1320-112, ID: 107731341, Assignment 4

vec1 = -8:-2
vec2 = linspace(-8,-2,7)

vec3 = 7:4:15
vec4 = linspace(7,15,3)

vec5 = 15:-5:5
vec6 = linspace(15,5,3)
