% This script creates an image processing menu driven application

%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%Margaux McFarland, CSC1 1320-112, ID: 107731341, Lab6/HW7
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;close all;clc;

% Display a menu and get a choice
choice = menu('Choose an option', 'Exit Program', 'Load Image', ...
    'Display Image', 'Brighten Image');  % as you develop functions, add 
                                         % buttons for them here
 
% Choice 1 is to exit the program
while choice ~= 1
   switch choice
       case 0
           disp('Error - please choose one of the options.')
           % Display a menu and get a choice
           choice = menu('Choose an option', 'Exit Program',...
               'Load Image', 'Display Image', 'Brighten Image');  
                      % as you develop functions, add buttons for them here
        case 2
           % Load an image
           image_choice = menu('Choose an image', 'lena1', 'mandril1',...
               'wrench', 'yoda');
           switch image_choice
               case 1
                   filename = 'lena1.jpg';
               case 2
                   filename = 'mandrill1.jpg'; 
               case 3
                   filename = 'wrench1.jpg'; 
               case 4
                   filename = 'yoda.bmp';
               % fill in cases for all the images you plan to use
           end
           current_img = imread(filename);
       case 3
           % Display image
           figure
           imagesc(current_img);
           if size(current_img,3) == 1
               colormap gray
           end
           
       case 4
           % Brighten image
           
           choice2 = menu('Choose way to brighten','Loops','No Loops');
           
           switch choice2
               case 0
                     disp('Error - please choose one of the options.')
                    % Display a menu and get a choice
                    choice2 = menu('Choose way to brighten','Loops','No Loops');
               case 1
                   
                    %Loops
                    % 1. Ask the user for brightness value
                    brightness = input('By how much (-255,255) would you like to brighten the image?\n');
                    % create your own function for brightening
                    otherImage = makeBright_L(current_img,brightness);
                    % 3. Display the old and the new image using subplot
           
                    subplot(1,2,1);
                    imagesc(current_img);
           
                    subplot(1,2,2);
                    imagesc(otherImage);
                    if size(current_img,3) == 1
                        colormap gray
                    end
                    % 4. Save the newImage to a file
                    imwrite(otherImage,'brightened.png');
               case 2
                   %no loops
                   % 1. Ask the user for brightness value
                   brightness = input('By how much (-255,255) would you like to brighten the image?\n');
                   
                   
                   % 2. Call the appropriate function
                   
                   otherImage = makeBright_NL(current_img, brightness);
                   %display
                   
                   subplot(1,2,1);
                   imagesc(current_img);
                   
                   subplot(1,2,2);
                   imagesc(otherImage);
                   if size(current_img,3) == 1
                       colormap gray
                   end
                   % 4. Save the newImage to a file
                   imwrite(otherImage,'brightened.png');
           end
              
       case 5
           
           
       %....
   end
   % Display menu again and get user's choice
   choice = menu('Choose an option', 'Exit Program', 'Load Image', ...
    'Display Image', 'Brighten Image'); 
   % as you develop functions, add buttons for them here
end
